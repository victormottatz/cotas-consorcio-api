import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SUPABASE_URL = os.getenv('SUPABASE_URL')
    SUPABASE_KEY = os.getenv('SUPABASE_KEY')
    WHATSAPP_NUMBER = os.getenv('WHATSAPP_NUMBER', '5511999999999')